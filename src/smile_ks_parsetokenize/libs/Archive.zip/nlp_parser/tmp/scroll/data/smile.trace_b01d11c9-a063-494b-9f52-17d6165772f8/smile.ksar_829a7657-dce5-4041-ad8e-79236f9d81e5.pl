:- style_check(-discontiguous).
:- ensure_loaded("/Users/mie008443/work/udc/smile-ks-parsetokenize/src/smile_ks_parsetokenize/libs/nlp_parser/tmp/scroll//prolog/parsing").
:- dynamic coref/1.
text("St.Mary's Church provides hot meals and addiction support to homeless youth.").
gram(0,"ROOT",["ROOT-0", "NONE"],["provides-4", "VBZ"]).
gram(1,"nmod:poss",["Church-3", "NNP"],["St.Mary-1", "NNP"]).
gram(2,"case",["St.Mary-1", "NNP"],["'s-2", "POS"]).
gram(3,"nsubj",["provides-4", "VBZ"],["Church-3", "NNP"]).
gram(4,"amod",["meals-6", "NNS"],["hot-5", "JJ"]).
gram(5,"obj",["provides-4", "VBZ"],["meals-6", "NNS"]).
gram(6,"cc",["support-9", "NN"],["and-7", "CC"]).
gram(7,"compound",["support-9", "NN"],["addiction-8", "NN"]).
gram(8,"conj",["meals-6", "NNS"],["support-9", "NN"]).
gram(9,"case",["youth-12", "NN"],["to-10", "IN"]).
gram(10,"amod",["youth-12", "NN"],["homeless-11", "JJ"]).
gram(11,"obl",["provides-4", "VBZ"],["youth-12", "NN"]).
gram(12,"punct",["provides-4", "VBZ"],[".-13", "."]).
