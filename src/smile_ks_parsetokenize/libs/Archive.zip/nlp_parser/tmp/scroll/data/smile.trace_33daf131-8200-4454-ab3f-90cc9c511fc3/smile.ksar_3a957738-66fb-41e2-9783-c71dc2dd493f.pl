:- style_check(-discontiguous).
:- ensure_loaded("/Users/mie008443/work/udc/smile-ks-parsetokenize/src/smile_ks_parsetokenize/libs/nlp_parser/tmp/scroll//prolog/parsing").
:- dynamic coref/1.
text("St. Mary's Church provides hot meals  and  addiction support to 90 of homeless youth.").
gram(0,"ROOT",["ROOT-0", "NONE"],["provides-5", "VBZ"]).
gram(1,"compound",["Mary-2", "NNP"],["St.-1", "NNP"]).
gram(2,"nmod:poss",["Church-4", "NNP"],["Mary-2", "NNP"]).
gram(3,"case",["Mary-2", "NNP"],["'s-3", "POS"]).
gram(4,"nsubj",["provides-5", "VBZ"],["Church-4", "NNP"]).
gram(5,"amod",["meals-7", "NNS"],["hot-6", "JJ"]).
gram(6,"obj",["provides-5", "VBZ"],["meals-7", "NNS"]).
gram(7,"cc",["support-10", "NN"],["and-8", "CC"]).
gram(8,"compound",["support-10", "NN"],["addiction-9", "NN"]).
gram(9,"conj",["meals-7", "NNS"],["support-10", "NN"]).
gram(10,"case",["90-12", "CD"],["to-11", "IN"]).
gram(11,"obl",["provides-5", "VBZ"],["90-12", "CD"]).
gram(12,"case",["youth-15", "NN"],["of-13", "IN"]).
gram(13,"amod",["youth-15", "NN"],["homeless-14", "JJ"]).
gram(14,"nmod",["90-12", "CD"],["youth-15", "NN"]).
gram(15,"punct",["provides-5", "VBZ"],[".-16", "."]).
